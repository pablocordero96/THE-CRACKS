<!DOCTYPE html>
<html>
    <head>
        <title>Mercado Polizona</title> 
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/fontello.css">
	    <link rel="stylesheet" type="text/css" href="css/menu.css">
	    <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
		<script type="text/javascript" src="js/app.js"></script>
    </head>
    
    <!--.........................................MENÚ......................................................-->
    <body>
        <STYLE>A {text-decoration: none;} </STYLE>
           
            <div class="contenedor-menu" align=center>            
                    <nav class="menu-escritorio">
                        <div><a href="embarques.php" target="search">Embarques</a></div>
                        <div><a href="financieras.php" target="search">Financieras</a></div>
                        <div><a><h1>Mercado Polizona</h1></a></div>
                        <div><a href="encadenamientos.php" target="search">Encadenamientos</a></div>
                        <div><a href="costospromedio.php" target="search">Costos Promedio</a></div>
                    </nav>

                    <nav>
                        <div class="menu-movil"><span id="colapsable" class="icon-menu-1"></span>Mercado Polizona</div>
                    </nav>

                    <div class="menu-contenido-movil">
                        <div align=left><a href="embarques.php" target="search">Embarques</a></div>
                        <div align=left><a href="financieras.php" target="search">Financieras</a></div>
                        <div align=left><a href="encadenamientos.php" target="search">Encadenamientos</a></div>
                        <div align=left><a href="costospromedio.php" target="search">Costos Promedio</a></div>
                    </div>     
            </div>
      <br>
      <br>
      <br>
      <br>
        <div id="contenedor" style="width:100%; height: 800px;" align="center">
                <iframe name="search" id="principal" src="embarques.php"></iframe>
        </div> 
    </body>
    <footer>
            <small>Copyright ©2019 Jhonatan Jovanny Medina Rosales.</small>
    </footer>
</html>